# SilverBridge 图标版使用说明

保留英文界面；本文件用中文帮助安装。两个 APP 仍然分开，各有自己的图标和数据库。

## 电脑上点图标打开

1. 安装 Python 3.11 或更新版本，安装时勾选 PATH，并保留默认的 Tcl/Tk 和 Python Launcher。
2. 完整解压此 ZIP 到固定、可写的文件夹。不要直接在压缩包里运行。
3. 双击 `create_desktop_icon_windows.bat`，只需要操作一次。
4. 桌面出现 SilverBridge 图标。之后双击图标，就会启动 Python 并自动打开界面，不用输入地址。
5. 使用时保持小型 Python server 窗口开启；它也显示给同一 Wi-Fi 手机使用的地址。结束时点击 Stop server and close。

也可以直接双击 `start_desktop_windows.bat`。如果移动了整个文件夹，请重新创建图标。

当前源码版的电脑图标启动后会打开默认浏览器。想要独立的应用窗口，可以在 Chrome / Edge 中点击 Install app 安装；本地 Python 服务仍需由桌面启动器先开启。

## 手机上点图标打开

同一 Wi-Fi 试用：先启动电脑程序，手机打开窗口显示的电脑地址，端口为 8765。不能在手机上输入 127.0.0.1 来连接电脑。

正式安装或跨地区使用：需要把 Python 服务部署到 HTTPS 域名。相关文件已放在包内，步骤见 `docs/HTTPS_DEPLOYMENT.md`。本次没有替你购买或部署服务器。

- iPhone：Safari 打开 HTTPS 地址 → 分享 → 添加到主屏幕。
- Android：Chrome 打开 HTTPS 地址 → Install app，或浏览器菜单 → 安装应用 / 添加到主屏幕。

安装后手机上有独立图标，支持时会以独立窗口打开。这是 PWA 安装方式，包内没有原生 APK 或 App Store 安装包。普通局域网 HTTP 地址可能只能添加书签，手机录音也可能受限。手机使用时需要服务器在线。

## 上传 GitHub

每个 APP 建一个仓库。解压后上传该文件夹里的内容，不要只上传 ZIP，也不要多套一层文件夹。保留 `.github/workflows/windows.yml`。不要上传 `local_data` 或真实使用记录。

上传到 main/master 后，Actions 里的 Test and build Windows app 会测试并构建 Windows 应用。成功后在该次运行页面下载 SilverBridge-Windows，完整解压，双击 SilverBridge.exe。这个构建结果会包含 Python，接收者无需另装 Python。

本包提供的是源码和自动构建流程，尚未在你的 GitHub 中生成 EXE。GitHub 存源码不等于服务已经上线；GitHub Pages 不能运行 Python 后端。完整说明见 `docs/GITHUB.md`。

## Python 写了哪些部分

Python 负责桌面启动器、服务器、数据库、业务逻辑和校验。手机及电脑界面使用 HTML/CSS/JavaScript 展示，操作仍由同一 Python 服务处理。
