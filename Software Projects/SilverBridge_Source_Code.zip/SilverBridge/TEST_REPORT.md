# SilverBridge icon edition - Validation

Version 2.0.0-en, 2026-10-18.

- 16 Python tests passed, including the previous feature suite and real HTTP manifest/icon delivery, desktop server startup/reuse, packaged-data path handling and private-file exclusion.
- Stub-DOM interface tests passed.
- PWA behavior tests passed: deferred install prompt, secure-context registration, installed-mode button state, offline reconnect fallback and no interception or caching of private API records.
- `python launcher.pyw --smoke-test` started the real Python server and checked app resources/state successfully without a GUI.
- Both command-line apps ran at the same time on separate ports and retained their independent databases.

Limits: this Linux environment cannot validate a Windows shortcut or EXE, has no graphical browser for visual QA, and cannot verify installation on physical iOS/Android devices. The GitHub workflow performs the actual Windows build and executable smoke test when run. No cloud service, domain or GitHub repository was created, and HTTPS deployment templates were not deployed here.
