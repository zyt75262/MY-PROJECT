# HTTPS deployment for phone installation and cross-region sharing

This is a deployment template, not an already deployed service. You supply a reachable server, a domain and Docker Engine with the Compose plugin. Server and domain charges depend on your provider. Start with a small trusted pilot; connected visitors can view and change shared records because the app has no account or access-code gate.

## One app on one server

1. Point your domain's DNS A record (and AAAA only if IPv6 is configured) to the server. The domain must resolve publicly to that server.
2. Allow inbound TCP 80 and 443 in the server/provider firewall. Do not expose the internal Python port 8765 directly.
3. Clone this GitHub repository onto the server, or copy its extracted contents there. Enter this app's folder.
4. Copy `.env.example` to `.env` and replace the example with your real domain, such as `silverbridge.your-domain.com`. Use only the hostname, without `https://` or a path.
5. Run:

```bash
docker compose up -d --build
docker compose logs --tail=80 app caddy
```

Caddy obtains HTTPS certificates when the public domain and ports are configured correctly. The Python service is reachable only inside the Compose network; Caddy forwards the original Host header to it. SQLite and HTTPS certificate state use persistent Docker volumes.

6. Open `https://YOUR_DOMAIN/api/health` and check that it reports `ok: true` and the correct app name. Then open `https://YOUR_DOMAIN`.
7. On the phone, open that HTTPS address and use Install / Add to Home Screen. Test a request and reply from two devices for SilverBridge, or a saved plan and swap for BrightBite.

Stop without deleting data: `docker compose down`. Restart with `docker compose up -d`. Avoid `down -v` unless you intend to delete persistent volumes. Back up the app data volume while the app is stopped.

## Hosting both apps on the same machine

The two supplied per-app Compose files each bind ports 80 and 443, so they cannot run unchanged on the same host simultaneously. Use one front-end Caddy service, two app services, separate databases/volumes and two domains. An operator can adapt the two app definitions and this Caddy routing example:

```text
silverbridge.your-domain.com {
    reverse_proxy silverbridge:8765
}
brightbite.your-domain.com {
    reverse_proxy brightbite:8766
}
```

Set each app's `APP_PUBLIC_HOST` to its own domain, keep app services off public ports and use a distinct volume for each. Each app is designed to live at the root of its own domain. Deploying at path prefixes such as `/silverbridge/` is not supported by these templates.

## What the app icon does

The phone installs the app's name, icon and standalone launch metadata. Python continues to run on the server. The service worker caches public interface files and an offline reconnect page only. It does not cache requests, screenshots, recordings, replies or plans; it does not submit changes later while offline. Changing the server domain or local IP may require reinstalling the icon.

References: [Caddy HTTPS](https://caddyserver.com/docs/quick-starts/https), [Caddy reverse proxy](https://caddyserver.com/docs/quick-starts/reverse-proxy), [PWA installation](https://web.dev/learn/pwa/installation/).
