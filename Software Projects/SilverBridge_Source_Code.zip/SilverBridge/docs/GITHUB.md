# Upload SilverBridge to GitHub

Use a separate repository for each app. Suggested name: `silverbridge-python-app`.

## Upload with the GitHub website

1. Sign in to GitHub and create a new repository. Choose Public or Private according to who should be able to see the code.
2. Extract this project's ZIP on your computer.
3. In the repository, select **Add file > Upload files**. Drag the extracted folder's **contents**, not the ZIP itself and not an extra enclosing folder.
4. Include `app.py`, `launcher.pyw`, `app_config.json`, `community`, `web`, `tests`, `scripts`, the README and the `.github` folder. The workflow file must be `.github/workflows/windows.yml` at the repository root. Files beginning with a dot belong in the repository too.
5. Choose **Commit changes**. Do not upload `local_data`, `.env`, `build`, `dist` or a real database. The supplied `.gitignore` excludes these when using Git.

Uploading only a ZIP stores a download; it does not activate the included workflow. If a folder or workflow was missed, upload it separately or use GitHub Desktop / Git.

## Git alternative

From inside this app's extracted folder, after creating an empty repository:

```bash
git init
git add .
git commit -m "Add SilverBridge Python app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Replace both placeholders with your account and repository. GitHub may ask you to authenticate using its normal sign-in flow.

## Get a clickable Windows application

1. Open the repository's **Actions** tab. Enable workflows if GitHub asks.
2. Open **Test and build Windows app**. A push to main/master starts it; you can also choose **Run workflow** on the default branch.
3. Wait for the run to finish successfully.
4. Open the run and download the **SilverBridge-Windows** artifact.
5. Extract the download completely and open `SilverBridge.exe`. Keep the whole directory, including `_internal`.
6. To add a desktop icon for that EXE, use Windows' **Send to > Desktop (create shortcut)** on the executable. The executable already includes the app icon.

The distribution includes Python. The workflow needs internet access to install the build tool and consumes GitHub Actions resources under your account's plan. Private-repository artifact links require authorized GitHub access. You may share the downloaded distribution with intended users directly.

The source package includes a workflow, not an already built or signed Windows installer. The supplied environment could validate Python and JavaScript logic but could not run Windows. The workflow performs the actual Windows build and packaged-server smoke test.

## Share a live phone app

A repository link shows the source. For a live cross-region app, use `HTTPS_DEPLOYMENT.md` and share the resulting HTTPS address. Users can then add the app to their phone home screen. GitHub Pages is static hosting and cannot execute this Python server.

References: [GitHub file uploads](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository), [Python workflows](https://docs.github.com/en/actions/tutorials/build-and-test-code/python), [PyInstaller](https://pyinstaller.org/en/stable/), [GitHub Pages limitations](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site).
