"""Python desktop launcher; the same server is used by desktop and phone clients."""
from __future__ import annotations

import json
import socket
import sys
import threading
import webbrowser
from pathlib import Path
from urllib.request import ProxyHandler, build_opener


def resource_root() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))


def data_root() -> Path:
    # A packaged executable must never write into PyInstaller's resource directory.
    base = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else resource_root()
    return base / "local_data"


class DesktopServer:
    def __init__(self, root: Path, database: Path, port: int):
        self.root, self.database, self.port = root, database, port
        self.config = json.loads((root / "app_config.json").read_text(encoding="utf-8"))
        self.server = None
        self.thread = None
        self.reused = False

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}/"

    def start(self):
        from .server import build_server
        try:
            server = build_server(self.root, self.database, self.port, host="0.0.0.0")
        except OSError as error:
            try:
                client = build_opener(ProxyHandler({}))
                with client.open(self.url + "api/health", timeout=2) as response:
                    health = json.load(response)
                if health.get("app") == self.config["id"] and str(health.get("version", "")).startswith("2."):
                    self.reused = True
                    return
            except (OSError, ValueError):
                pass
            raise RuntimeError(f"Port {self.port} is in use. Close an older app instance or use another port with app.py.") from error
        self.server = server
        self.port = server.server_port
        self.thread = threading.Thread(target=server.serve_forever, daemon=True)
        self.thread.start()

    def close(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.thread.join(timeout=3)
            self.server = None


def lan_urls(port: int) -> list[str]:
    try:
        addresses = {row[4][0] for row in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)}
    except OSError:
        addresses = set()
    return [f"http://{address}:{port}/" for address in sorted(addresses) if not address.startswith("127.")]


def main() -> int:
    import tkinter as tk
    from tkinter import messagebox, ttk
    root = resource_root()
    config = json.loads((root / "app_config.json").read_text(encoding="utf-8"))
    window = tk.Tk()
    window.title(config["name"] + " - Python server")
    window.geometry("660x580")
    window.minsize(620, 560)
    window.configure(bg="#f6f7f2")
    try:
        window.iconphoto(True, tk.PhotoImage(file=str(root / "web/icons/icon-192.png")))
    except tk.TclError:
        pass
    frame = ttk.Frame(window, padding=24)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text=config["name"], font=("Segoe UI", 24, "bold")).pack(anchor="w")
    ttk.Label(frame, text="Python app · desktop and phone access", font=("Segoe UI", 11)).pack(anchor="w", pady=(4, 18))
    server = DesktopServer(root, data_root() / "community.sqlite3", config["port"])
    try:
        server.start()
    except Exception as error:
        messagebox.showerror(config["name"], str(error), parent=window)
        window.destroy()
        return 1
    status = "Already running in another window. This window does not own that server." if server.reused else "Running. Keep this window open while using the app."
    ttk.Label(frame, text=status, wraplength=560).pack(anchor="w")
    ttk.Label(frame, text="Open on this computer:").pack(anchor="w", pady=(18, 4))
    local = ttk.Entry(frame)
    local.insert(0, server.url)
    local.configure(state="readonly")
    local.pack(fill="x")
    ttk.Button(frame, text="Open " + config["name"], command=lambda: webbrowser.open(server.url)).pack(anchor="w", pady=12)
    ttk.Label(frame, text="Phone on the same Wi-Fi (copy a computer address):").pack(anchor="w")
    addresses = tk.Text(frame, height=3, wrap="word", font=("Segoe UI", 10))
    addresses.insert("1.0", "\n".join(lan_urls(server.port)) or f"Run ipconfig and use http://COMPUTER_IPV4:{server.port}/")
    addresses.configure(state="disabled")
    addresses.pack(fill="x", pady=(4, 10))
    ttk.Label(frame, text="For an installed phone app across regions, use the HTTPS deployment.\nClosing this server stops connected clients. Your records remain saved.", wraplength=560).pack(anchor="w")

    def close():
        if not server.reused and not messagebox.askokcancel("Stop server?", "Connected devices will disconnect. Saved records will remain.", parent=window):
            return
        server.close()
        window.destroy()

    ttk.Button(frame, text="Close window" if server.reused else "Stop server and close", command=close).pack(anchor="e", pady=16)
    window.protocol("WM_DELETE_WINDOW", close)
    window.after(500, lambda: webbrowser.open(server.url))
    try:
        window.mainloop()
    finally:
        server.close()
    return 0


def smoke_test() -> int:
    import tempfile
    with tempfile.TemporaryDirectory() as temp:
        controller = DesktopServer(resource_root(), Path(temp) / "check.sqlite3", 0)
        try:
            controller.start()
            client = build_opener(ProxyHandler({}))
            for path in ["api/health", "manifest.webmanifest", "icons/icon-512.png", "app.js", "api/state"]:
                with client.open(controller.url + path, timeout=5) as response:
                    if response.status != 200:
                        raise RuntimeError("Packaged resource check failed: " + path)
                    response.read()
        finally:
            controller.close()
    return 0
