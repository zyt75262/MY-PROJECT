"""Verify the launcher and real HTTP install resources without requiring a GUI."""
import json
import struct
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import ProxyHandler, Request, build_opener

from community.desktop import DesktopServer, data_root, resource_root

ROOT = Path(__file__).resolve().parents[1]


class DesktopPWATests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.controller = DesktopServer(ROOT, Path(self.temp.name) / "app.sqlite3", 0)
        self.controller.start()
        self.client = build_opener(ProxyHandler({}))

    def tearDown(self):
        self.controller.close()
        self.temp.cleanup()

    def fetch(self, path):
        return self.client.open(self.controller.url + path, timeout=5)

    def test_install_manifest_and_declared_icons_are_served(self):
        with self.fetch("manifest.webmanifest") as response:
            self.assertIn("application/manifest+json", response.headers["Content-Type"])
            manifest = json.load(response)
        self.assertEqual(manifest["name"], self.controller.config["name"])
        self.assertEqual(manifest["display"], "standalone")
        self.assertEqual(manifest["start_url"], "/")
        self.assertEqual(manifest["scope"], "/")
        self.assertEqual({i["sizes"] for i in manifest["icons"]}, {"192x192", "512x512"})
        for icon in manifest["icons"]:
            with self.fetch(icon["src"].lstrip("/")) as response:
                raw = response.read()
                self.assertEqual(response.headers["Content-Type"], "image/png")
            self.assertEqual(raw[:8], b"\x89PNG\r\n\x1a\n")
            dimensions = struct.unpack(">II", raw[16:24])
            self.assertEqual("x".join(map(str, dimensions)), icon["sizes"])

    def test_shell_worker_and_offline_page_do_not_expose_private_files(self):
        for path in ["sw.js", "install.js", "offline.html", "icons/icon-180.png"]:
            with self.fetch(path) as response:
                self.assertEqual(response.status, 200)
                self.assertTrue(response.read())
                self.assertIn("worker-src 'self'", response.headers["Content-Security-Policy"])
        for path in ["local_data/community.sqlite3", "app_config.json", "../README.md"]:
            with self.assertRaises(HTTPError) as error:
                self.fetch(path)
            self.assertEqual(error.exception.code, 404)
        with self.fetch("api/state") as response:
            self.assertEqual(response.headers["Cache-Control"], "no-store")

    def test_second_launcher_reuses_server_without_stopping_owner(self):
        second = DesktopServer(ROOT, Path(self.temp.name) / "app.sqlite3", self.controller.port)
        second.start()
        self.assertTrue(second.reused)
        second.close()
        with self.fetch("api/health") as response:
            self.assertEqual(json.load(response)["app"], self.controller.config["id"])

    def test_packaged_data_directory_is_beside_executable_not_resources(self):
        temp = Path(self.temp.name).resolve()
        resources = temp / "frozen-resources"
        executable = temp / "installed" / "App.exe"
        with patch.object(sys, "frozen", True, create=True), patch.object(sys, "_MEIPASS", str(resources), create=True), patch.object(sys, "executable", str(executable)):
            self.assertEqual(resource_root(), resources)
            self.assertEqual(data_root(), executable.parent / "local_data")


if __name__ == "__main__":
    unittest.main()
