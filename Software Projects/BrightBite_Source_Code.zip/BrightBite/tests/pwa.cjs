// Behavioral checks: install prompt handoff, secure-only registration, API never cached.
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..');
const installer=fs.readFileSync(root+'/web/install.js','utf8');
function installContext({secure=true,standalone=false}={}){
 const handlers={},button={hidden:false,addEventListener:(name,fn)=>handlers['button:'+name]=fn};
 const registrations=[];
 const context={document:{querySelector:s=>s==='#installapp'?button:null},navigator:{serviceWorker:{register:async(...args)=>{registrations.push(args)}}},window:{isSecureContext:secure,matchMedia:()=>({matches:standalone}),addEventListener:(name,fn)=>handlers[name]=fn}};
 vm.createContext(context);vm.runInContext(installer,context);
 return {handlers,button,registrations};
}
(async()=>{
 const install=installContext();assert.equal(install.registrations.length,1);assert.equal(install.button.hidden,false);
 let prevented=false,prompts=0;
 install.handlers.beforeinstallprompt({preventDefault(){prevented=true},async prompt(){prompts++},userChoice:Promise.resolve({outcome:'accepted'})});
 assert(prevented);await install.handlers['button:click']();assert.equal(prompts,1);assert.equal(install.button.hidden,true);
 assert.equal(installContext({secure:false}).registrations.length,0);
 assert.equal(installContext({standalone:true}).button.hidden,true);
 const workerHandlers={},cached=[];
 const context={URL,Promise,self:{location:{origin:'https://example.test'},addEventListener:(name,fn)=>workerHandlers[name]=fn,skipWaiting:async()=>{},clients:{claim:async()=>{}}},caches:{open:async()=>({addAll:async items=>cached.push(...items)}),keys:async()=>[],match:async key=>({offline:key}),delete:async()=>true},fetch:async()=>{throw Error('offline')}};
 vm.createContext(context);vm.runInContext(fs.readFileSync(root+'/web/sw.js','utf8'),context);
 let installTask;workerHandlers.install({waitUntil:p=>installTask=p});await installTask;
 assert(cached.includes('/offline.html'));assert(!cached.some(p=>p.startsWith('/api/')));assert(!cached.includes('/'));
 for(const [pathname,method] of [['/api/shared','GET'],['/api/state','GET'],['/api/plans','POST'],['/api/tickets','POST']]){
  let intercepted=false;workerHandlers.fetch({request:{url:'https://example.test'+pathname,method,mode:'cors'},respondWith(){intercepted=true}});assert.equal(intercepted,false);
 }
 let navigation;workerHandlers.fetch({request:{url:'https://example.test/',method:'GET',mode:'navigate'},respondWith:p=>navigation=p});assert.equal((await navigation).offline,'/offline.html');
 console.log('PASS: secure installation, standalone icon mode, browser prompt, offline fallback, no caching or queuing of API records. Stub logic; physical-device install remains to be checked.');
})().catch(error=>{console.error(error);process.exit(1)});
