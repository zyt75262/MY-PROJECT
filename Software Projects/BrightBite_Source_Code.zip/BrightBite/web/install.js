/* Home-screen installation; data and operations continue to use the Python server. */
(()=>{
 'use strict';
 const button=document.querySelector('#installapp');
 if(!button)return;
 let pending=null;
 const standalone=()=>window.matchMedia?.('(display-mode: standalone)').matches||navigator.standalone===true;
 button.hidden=standalone();
 window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();pending=event;button.hidden=false;});
 window.addEventListener('appinstalled',()=>{pending=null;button.hidden=true;});
 button.addEventListener('click',async()=>{
  if(pending){const prompt=pending;pending=null;await prompt.prompt();const choice=await prompt.userChoice;if(choice.outcome==='accepted')button.hidden=true;return;}
  let dialog=document.querySelector('#installguide');
  if(!dialog){
   dialog=document.createElement('dialog');dialog.id='installguide';dialog.className='install-guide';
   dialog.innerHTML='<h2>Add this app to your device</h2><ol><li><strong>iPhone / iPad:</strong> open this address in Safari, choose Share, then Add to Home Screen.</li><li><strong>Android:</strong> open the browser menu and choose Install app or Add to Home screen.</li><li><strong>Computer:</strong> use the Install option in Chrome or Edge. The Python desktop shortcut starts the local server for you.</li></ol><p>Your icon opens this same server. Keep the server online to view, submit or synchronize records.</p><p id="installcontext"></p><button type="button">Close</button>';
   dialog.querySelector('button').addEventListener('click',()=>dialog.close());document.body.append(dialog);
  }
  dialog.querySelector('#installcontext').textContent=window.isSecureContext?'If an Install option is not offered, you can use the browser menu. Available options depend on the device and browser.':'This local HTTP address may create only a bookmark. Use the HTTPS deployment for a full phone installation and microphone access.';
  dialog.showModal();
 });
 if('serviceWorker' in navigator&&window.isSecureContext){navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>{});}
})();
