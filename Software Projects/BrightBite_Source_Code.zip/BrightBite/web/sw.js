// Cache only public shell assets. Shared requests, replies and plans are never cached.
const PREFIX = 'brightbite-shell-';
const CACHE = PREFIX + '2.0.0';
const ASSETS = ['/offline.html','/styles.css','/app.js','/install.js','/icons/icon-192.png','/icons/icon-512.png','/icons/icon-180.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith(PREFIX)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
 if(event.request.mode==='navigate'){
  event.respondWith(fetch(event.request).catch(()=>caches.match('/offline.html')));
 }else if(ASSETS.includes(url.pathname)){
  event.respondWith(fetch(event.request).catch(()=>caches.match(url.pathname)));
 }
});
