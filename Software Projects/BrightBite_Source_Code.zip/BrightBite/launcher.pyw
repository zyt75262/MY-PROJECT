"""Double-click to start; --smoke-test verifies a packaged build without a GUI."""
import sys
from community.desktop import main, smoke_test

if __name__ == "__main__":
    raise SystemExit(smoke_test() if '--smoke-test' in sys.argv else main())
