# BrightBite - Python app with desktop and phone icons

BrightBite is an independent Python application. The server, database, validation and desktop launcher use Python. HTML, CSS and JavaScript provide a responsive interface for computers and phones. The English interface and existing app features are retained.

![BrightBite icon](web/icons/icon-192.png)

## Open from a Windows desktop icon

1. Install Python 3.11 or newer, including Tcl/Tk and the Python launcher. No additional runtime packages are needed.
2. Extract this entire ZIP to a writable folder and keep it there.
3. Double-click `create_desktop_icon_windows.bat` once.
4. A BrightBite icon appears on your desktop. Double-click it to start the Python server and open the app. You do not need to type a command or a browser address.
5. Keep the small **BrightBite - Python server** window open. It shows the address for phones on the same Wi-Fi. Use **Stop server and close** when finished.

The icon starts Python and opens the interface in the default browser. For an app-style separate window, install the app from Chrome or Edge using **Install app**. A local installed icon cannot start a stopped Python server: use the Python desktop shortcut first. A publicly hosted app does not require your personal computer to run the server.

You can also double-click `start_desktop_windows.bat`. On macOS/Linux, run `python3 launcher.pyw`; a working Tk installation is required. On headless machines, use `python app.py --share --no-browser`.

## Add a phone home-screen icon

For the full installed experience, publish this Python app at its own HTTPS domain using `docs/HTTPS_DEPLOYMENT.md`. Open that HTTPS address on the phone:

- **iPhone/iPad:** open in Safari, choose Share, then Add to Home Screen.
- **Android:** open in Chrome or another supported browser, tap **Install app**, or choose Install / Add to Home screen from the browser menu.

Each app has its own name and icon. When supported, it opens in a standalone window. Installation behavior varies by platform. This is an installable web app (PWA), not an included native APK or App Store package. The Python backend remains on the computer or server; it is not installed inside the phone.

For a same-Wi-Fi trial, use the address shown in the Python server window, such as `http://COMPUTER_IP:8766`. Plain HTTP on a phone may only offer a bookmark and may block the microphone. HTTPS is required for the full PWA install and service-worker features outside localhost.

The server must stay reachable to view, submit or synchronize records. When it is unavailable, an installed app can show a reconnect page. Private records and uploads are not cached or queued for offline use.

## Upload to GitHub and build a Windows EXE

See `docs/GITHUB.md`. This package contains the complete source and a GitHub Actions workflow. Upload this folder's **contents** to the root of a separate repository for BrightBite; include `.github/workflows/windows.yml`.

The workflow tests the app, builds a Windows distribution with Python included and smoke-tests it. When the workflow succeeds, download `BrightBite-Windows` from the run's Artifacts, extract the full folder, and double-click `BrightBite.exe`. Recipients of that built distribution do not need to install Python. Keep `_internal` beside the EXE.

This source ZIP does not already contain a Windows EXE. The workflow has been prepared but has not been run in your GitHub account. You can also build locally on Windows with `build_windows.bat`.

GitHub stores source and build artifacts. GitHub Pages cannot run the Python backend. Use the HTTPS server deployment for live shared records across regions.

## Existing features and data

Detailed instructions, old-record import and troubleshooting: `docs/USER_GUIDE.md`. Keep the old database import tool and user attribution files with the project.

- Default port: 8766.
- Data: `local_data/community.sqlite3`, beside the source folder or the built EXE. Do not upload personal records to GitHub.
- SilverBridge and BrightBite have separate folders, ports, databases and icons.
- No shared code or personal-account gate is added.
- English recipe names, preparation, health notes and exports are retained in BrightBite.

## Validation

```bash
python -m unittest discover -s tests -v
node tests/ui_render.cjs
node tests/pwa.cjs
python launcher.pyw --smoke-test
```

Python is required to run source. Node is only needed for optional rendering tests. The complete test scope and untested device-specific steps are recorded in `TEST_REPORT.md`.
