@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 import_old_data.py
) else (
    python import_old_data.py
)
pause
