"""Install a Windows desktop icon using Python and the built-in shortcut API."""
import json
import os
import subprocess
import sys
from pathlib import Path


def main():
    if sys.platform != "win32":
        print("This shortcut installer is for Windows. Run python launcher.pyw on macOS/Linux.")
        return 1
    root = Path(__file__).resolve().parent
    config = json.loads((root / "app_config.json").read_text(encoding="utf-8"))
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    if not pythonw.is_file():
        pythonw = Path(sys.executable)
    env = dict(os.environ, APP_SHORTCUT_NAME=config["name"], APP_SHORTCUT_PYTHON=str(pythonw),
               APP_SHORTCUT_ARGS=subprocess.list2cmdline([str(root / "launcher.pyw")]),
               APP_SHORTCUT_ROOT=str(root), APP_SHORTCUT_ICON=str(root / "web/icons/app.ico"))
    # Paths are supplied through environment variables, never interpolated as PowerShell code.
    script = """
$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('Desktop')
$link = Join-Path $desktop ($env:APP_SHORTCUT_NAME + '.lnk')
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($link)
$shortcut.TargetPath = $env:APP_SHORTCUT_PYTHON
$shortcut.Arguments = $env:APP_SHORTCUT_ARGS
$shortcut.WorkingDirectory = $env:APP_SHORTCUT_ROOT
$shortcut.IconLocation = $env:APP_SHORTCUT_ICON
$shortcut.Description = $env:APP_SHORTCUT_NAME + ' - Python application'
$shortcut.Save()
Write-Output $link
"""
    subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script], env=env, check=True)
    print("Desktop icon created. Keep this extracted folder in its current location.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
