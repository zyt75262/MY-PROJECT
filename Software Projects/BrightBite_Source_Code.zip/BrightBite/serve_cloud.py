"""Start the Python app behind the included HTTPS reverse proxy."""
import os
import re
import sys
from pathlib import Path
from app import main

if __name__=='__main__':
    hostname=os.environ.get('APP_PUBLIC_HOST','').strip().lower()
    if not re.fullmatch(r'(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?',hostname) or '.' not in hostname:
        raise SystemExit('Set APP_PUBLIC_HOST to your domain name only, without https:// or a path.')
    sys.argv=['app.py','--share','--no-browser','--public-host',hostname,'--data-dir',os.environ.get('APP_DATA_DIR','/app/local_data')]
    raise SystemExit(main())
