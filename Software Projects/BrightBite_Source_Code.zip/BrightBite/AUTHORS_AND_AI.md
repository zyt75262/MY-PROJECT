# BrightBite - Authors and AI assistance

The user supplied the project ideas, design requirements and feature requests. ChatGPT assisted with implementation, separation into independent apps, English localization and validation. Runnable Python source, automated checks and documentation are included.

This package does not establish that the user independently wrote all code or conducted community field trials. Project descriptions should distinguish personal research, design, development and testing from AI-assisted work.

Version 2.0.0-en, 2026-10-18. No real user records are packaged with the source.

This version also includes AI-assisted desktop launcher, PWA installation and packaging templates.
