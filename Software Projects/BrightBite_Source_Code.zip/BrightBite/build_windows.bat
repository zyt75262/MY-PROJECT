@echo off
cd /d "%~dp0"
python -m pip install -r requirements-build.txt
if errorlevel 1 goto end
python scripts/build_windows.py
:end
pause
