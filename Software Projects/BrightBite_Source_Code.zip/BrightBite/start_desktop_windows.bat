@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 launcher.pyw
) else (
  python launcher.pyw
)
if errorlevel 1 pause
