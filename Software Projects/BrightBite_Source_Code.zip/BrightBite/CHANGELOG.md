# BrightBite 2.0.0-en

2026-10-18

- Added a Python graphical server launcher and Windows desktop shortcut installer.
- Added separate app icons, web app manifest, installation guidance and offline reconnect page.
- Kept private records out of the service-worker cache.
- Added GitHub Actions Windows packaging and packaged-resource smoke test.
- Added HTTPS Docker/Caddy deployment templates with persistent data volumes.
- Preserved independent app data, English localization, old-data import and app-specific features.
