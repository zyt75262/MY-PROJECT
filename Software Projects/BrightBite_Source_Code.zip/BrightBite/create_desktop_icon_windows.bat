@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 create_desktop_shortcut.py
) else (
  python create_desktop_shortcut.py
)
pause
