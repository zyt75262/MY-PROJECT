"""Build a Windows distribution containing Python; run on Windows only."""
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
if sys.platform!='win32':
    raise SystemExit('Build on Windows or run the GitHub Actions Windows workflow.')
config=json.loads((root/'app_config.json').read_text())
command=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--windowed','--onedir',
 '--name',config['name'],'--icon',str(root/'web/icons/app.ico'),
 '--add-data',str(root/'web')+os.pathsep+'web',
 '--add-data',str(root/'app_config.json')+os.pathsep+'.']
if (root/'data').exists():command+=['--add-data',str(root/'data')+os.pathsep+'data']
command.append(str(root/'launcher.pyw'))
subprocess.run(command,cwd=root,check=True)
print('Built: dist/'+config['name']+'/'+config['name']+'.exe')
print('Distribute the entire folder, including _internal, not just the EXE.')
